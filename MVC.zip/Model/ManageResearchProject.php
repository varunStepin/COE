<?php

App::uses('Model', 'Model');

class ManageResearchProject extends AppModel {
	//public $belongsTo=array("");
    
	
}
