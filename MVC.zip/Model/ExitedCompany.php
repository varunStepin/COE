<?php
App::uses('Model', 'Model');
class ExitedCompany extends AppModel {
    var $actsAs = array('SoftDeletable');
}
