<?php
App::uses('Model', 'Model');
class GraduateSchool extends AppModel {
    var $actsAs = array('SoftDeletable');

}
