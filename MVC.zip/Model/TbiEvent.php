<?php
App::uses('Model', 'Model');
class TbiEvent extends AppModel {
    //var $actsAs = array('SoftDeletable');
  
   
}