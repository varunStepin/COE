<?php
App::uses('Model', 'Model');
class InvestorConnect extends AppModel {
    //public $belongsTo=array("");
}
