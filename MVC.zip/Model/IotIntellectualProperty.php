<?php
App::uses('Model', 'Model');
class IotIntellectualProperty extends AppModel {
    var $actsAs = array('SoftDeletable');

}
