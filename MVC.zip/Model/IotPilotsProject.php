<?php
App::uses('Model', 'Model');
class IotPilotsProject extends AppModel {
    var $actsAs = array('SoftDeletable');

}
