<?php
App::uses('Model', 'Model');
class IotDelegation extends AppModel {
    var $actsAs = array('SoftDeletable');

}
