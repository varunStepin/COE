<?php
App::uses('Model', 'Model');
class CifStartup extends AppModel {
    var $actsAs = array('SoftDeletable');
}