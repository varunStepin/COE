<?php

App::uses('Model', 'Model');

class ManageSkill extends AppModel {
	//public $belongsTo=array("");
    
	
}
