<?php
App::uses('Model', 'Model');
class CifGenderDiversity extends AppModel {
    var $actsAs = array('SoftDeletable');
}