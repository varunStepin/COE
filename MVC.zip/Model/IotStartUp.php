<?php
App::uses('Model', 'Model');
class IotStartUp extends AppModel {
    var $actsAs = array('SoftDeletable');

}
