<?php

App::uses('Model', 'Model');

class ManageAttendees extends AppModel {
	public $belongsTo=array("ManageTraining");
    
	
}
