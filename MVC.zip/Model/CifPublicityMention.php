<?php
App::uses('Model', 'Model');
class CifPublicityMention extends AppModel {
    var $actsAs = array('SoftDeletable');
}