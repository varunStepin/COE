<?php
App::uses('Model', 'Model');
class MiInternationalConferences extends AppModel {
}
