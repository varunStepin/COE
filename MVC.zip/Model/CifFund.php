<?php
App::uses('Model', 'Model');
class CifFund extends AppModel {
    var $actsAs = array('SoftDeletable');
}