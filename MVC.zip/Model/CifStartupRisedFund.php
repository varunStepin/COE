<?php
App::uses('Model', 'Model');
class CifStartupRisedFund extends AppModel {
    var $actsAs = array('SoftDeletable');
}