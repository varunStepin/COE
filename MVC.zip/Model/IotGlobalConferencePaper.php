<?php
App::uses('Model', 'Model');
class IotGlobalConferencePaper extends AppModel {
    var $actsAs = array('SoftDeletable');

}
