<?php
App::uses('Model', 'Model');
class IotOtherProgram extends AppModel {
    var $actsAs = array('SoftDeletable');

}
