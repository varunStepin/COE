<?php
App::uses('Model', 'Model');
class MinroWorkshop extends AppModel {
    var $actsAs = array('SoftDeletable');
}
