<?php
App::uses('Model', 'Model');
class CifExternalEvent extends AppModel {
    var $actsAs = array('SoftDeletable');
}