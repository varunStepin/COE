<?php
App::uses('Model', 'Model');
class CifExternalEventParticipant extends AppModel {
    var $actsAs = array('SoftDeletable');
}