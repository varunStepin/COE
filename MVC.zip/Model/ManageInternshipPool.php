<?php

App::uses('Model', 'Model');

class ManageInternshipPool extends AppModel {

}
