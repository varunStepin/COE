<?php
App::uses('Model', 'Model');
class TbiTarget extends AppModel {
    var $actsAs = array('SoftDeletable');
}