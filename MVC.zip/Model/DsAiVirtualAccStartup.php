<?php
App::uses('Model', 'Model');
class DsAiVirtualAccStartup extends AppModel {
    var $actsAs = array('SoftDeletable');

}
