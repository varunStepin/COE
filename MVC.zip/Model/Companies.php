<?php
App::uses('Model', 'Model');
class Companies extends AppModel {
    var $actsAs = array('SoftDeletable');
}
