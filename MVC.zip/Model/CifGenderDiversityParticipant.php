<?php
App::uses('Model', 'Model');
class CifGenderDiversityParticipant extends AppModel {
    var $actsAs = array('SoftDeletable');
}