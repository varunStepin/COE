<?php
App::uses('Model', 'Model');
class TbiStartup extends AppModel {
    var $actsAs = array('SoftDeletable');

}
