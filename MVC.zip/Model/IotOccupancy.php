<?php
App::uses('Model', 'Model');
class IotOccupancy extends AppModel {
    var $actsAs = array('SoftDeletable');

}
