<?php

App::uses('Model', 'Model');

class ManageWorkingAttendee extends AppModel {
	public $belongsTo=array("ManageWorking");
    
	
}
