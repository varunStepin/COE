<?php
App::uses('Model', 'Model');
class DsTechMentoring extends AppModel {
    var $actsAs = array('SoftDeletable');
}
