<?php
App::uses('Model', 'Model');
class DsSolutionsAdopted extends AppModel {
    var $actsAs = array('SoftDeletable');
}
