<?php

App::uses('Model', 'Model');

class ResearchProjectTeam extends AppModel {
	public $belongsTo=array("ManageResearchProject");
    
	
}
