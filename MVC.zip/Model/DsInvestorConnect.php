<?php
App::uses('Model', 'Model');
class DsInvestorConnect extends AppModel {
    var $actsAs = array('SoftDeletable');
}
