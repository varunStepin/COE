<?php

App::uses('Model', 'Model');

class Trainee extends AppModel {
	//public $belongsTo=array("");
    
	
}
