<?php
App::uses('Model', 'Model');
class IotIncubatedResearcher extends AppModel {
    var $actsAs = array('SoftDeletable');

}
