<?php
App::uses('Model', 'Model');
class MiMentorship extends AppModel {
    var $actsAs = array('SoftDeletable');

}
