<?php
App::uses('Model', 'Model');
class KtechFundRaisedStartup extends AppModel {
    var $actsAs = array('SoftDeletable');
}
