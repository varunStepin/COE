<?php

App::uses('Model', 'Model');

class ManageSkillAttendee extends AppModel {
	public $belongsTo=array("ManageSkill");
    
	
}
