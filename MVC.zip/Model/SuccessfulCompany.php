<?php
App::uses('Model', 'Model');
class SuccessfulCompany extends AppModel {
    var $actsAs = array('SoftDeletable');
}
