<?php
App::uses('Model', 'Model');
class DsAiTrainedProfessional extends AppModel {
    var $actsAs = array('SoftDeletable');

}
