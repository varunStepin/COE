<?php
App::uses('Model', 'Model');
class MarketResearch extends AppModel {
    //public $belongsTo=array("");
}
