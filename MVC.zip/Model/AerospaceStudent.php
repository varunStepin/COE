<?php

App::uses('Model', 'Model');

class AerospaceStudent extends AppModel {
	public $belongsTo=array("ManageAerospaceTraining");
    
	
}
