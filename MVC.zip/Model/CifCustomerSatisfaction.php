<?php
App::uses('Model', 'Model');
class CifCustomerSatisfaction extends AppModel {
    var $actsAs = array('SoftDeletable');
}