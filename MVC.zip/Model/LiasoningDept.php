<?php
App::uses('Model', 'Model');
class LiasoningDept extends AppModel {
    //public $belongsTo=array("");
}
