<?php

App::uses('Model', 'Model');

class TraineeSecuredJob extends AppModel {
	//public $belongsTo=array("");
    
	
}
