<?php
App::uses('Model', 'Model');
class IotShowcasedPrototype extends AppModel {
    var $actsAs = array('SoftDeletable');

}
