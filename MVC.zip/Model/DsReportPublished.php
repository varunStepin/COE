<?php
App::uses('Model', 'Model');
class DsReportPublished extends AppModel {
    var $actsAs = array('SoftDeletable');
}
