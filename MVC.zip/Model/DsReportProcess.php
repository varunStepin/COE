<?php
App::uses('Model', 'Model');
class DsReportProcess extends AppModel {
    var $actsAs = array('SoftDeletable');
}
