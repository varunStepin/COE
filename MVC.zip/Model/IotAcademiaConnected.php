<?php
App::uses('Model', 'Model');
class IotAcademiaConnected extends AppModel {
    var $actsAs = array('SoftDeletable');

}
