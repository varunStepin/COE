<?php
App::uses('Model', 'Model');
class MiOpenExperienceCentre extends AppModel {
    var $actsAs = array('SoftDeletable');

}
