<?php
App::uses('Model', 'Model');
class CifTarget extends AppModel {
    var $actsAs = array('SoftDeletable');
}