<?php

App::uses('Model', 'Model');

class EnrolledTrainer extends AppModel {
	//public $belongsTo=array("");
    
	
}
