<?php
App::uses('Model', 'Model');
class KtechMentor extends AppModel {
    var $actsAs = array('SoftDeletable');
}
