<?php

App::uses('Model', 'Model');

class InternshipPoolIntern extends AppModel {
	public $belongsTo=array("ManageInternshipPool");
    
	
}
