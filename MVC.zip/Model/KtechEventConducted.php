<?php
App::uses('Model', 'Model');
class KtechEventConducted extends AppModel {
    var $actsAs = array('SoftDeletable');
}
