<?php

App::uses('Model', 'Model');

class SolutionSupport extends AppModel {
	//public $belongsTo=array("");
    
	
}
