<?php
App::uses('Model', 'Model');
class KtechPartnership extends AppModel {
    var $actsAs = array('SoftDeletable');
}
