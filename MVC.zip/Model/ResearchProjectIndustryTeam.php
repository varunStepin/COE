<?php

App::uses('Model', 'Model');

class ResearchProjectIndustryTeam extends AppModel {
	public $belongsTo=array("ManageResearchProjectIndustry");
    
	
}
