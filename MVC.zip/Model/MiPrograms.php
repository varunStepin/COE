<?php
App::uses('Model', 'Model');
class MiPrograms extends AppModel {
}
