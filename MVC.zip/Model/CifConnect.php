<?php
App::uses('Model', 'Model');
class CifConnect extends AppModel {
    var $actsAs = array('SoftDeletable');
}