<?php
App::uses('Model', 'Model');
class CifRoundtable extends AppModel {
    var $actsAs = array('SoftDeletable');
}