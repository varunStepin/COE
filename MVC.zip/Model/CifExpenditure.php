<?php
App::uses('Model', 'Model');
class CifExpenditure extends AppModel {
    var $actsAs = array('SoftDeletable');
}