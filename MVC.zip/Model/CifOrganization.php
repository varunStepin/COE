<?php
App::uses('Model', 'Model');
class CifOrganization extends AppModel {
    var $actsAs = array('SoftDeletable');
}