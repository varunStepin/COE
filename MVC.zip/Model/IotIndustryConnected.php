<?php
App::uses('Model', 'Model');
class IotIndustryConnected extends AppModel {
    var $actsAs = array('SoftDeletable');

}
