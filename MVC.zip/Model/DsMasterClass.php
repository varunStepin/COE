<?php
App::uses('Model', 'Model');
class DsMasterClass extends AppModel {
    var $actsAs = array('SoftDeletable');
}
