<?php
App::uses('Model', 'Model');
class   IotStartupsRisedFund extends AppModel {
    var $actsAs = array('SoftDeletable');

}
