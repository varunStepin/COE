<?php

App::uses('Model', 'Model');

class ManageWorking extends AppModel {
	//public $belongsTo=array("");
    
	
}
