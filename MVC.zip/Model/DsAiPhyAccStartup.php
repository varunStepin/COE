<?php
App::uses('Model', 'Model');
class DsAiPhyAccStartup extends AppModel {
    var $actsAs = array('SoftDeletable');

}
