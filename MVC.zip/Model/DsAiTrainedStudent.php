<?php
App::uses('Model', 'Model');
class DsAiTrainedStudent extends AppModel {
    var $actsAs = array('SoftDeletable');

}
