<?php
App::uses('Model', 'Model');
class MiStartupConferences extends AppModel {
}
