<?php
App::uses('Model', 'Model');
class RevenueGenerated extends AppModel {
    var $actsAs = array('SoftDeletable');
}
