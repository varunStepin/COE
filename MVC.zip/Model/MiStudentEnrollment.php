<?php
App::uses('Model', 'Model');
class MiStudentEnrollment extends AppModel {
    var $actsAs = array('SoftDeletable');
}
