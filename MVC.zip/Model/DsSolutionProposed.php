<?php
App::uses('Model', 'Model');
class DsSolutionProposed extends AppModel {
    var $actsAs = array('SoftDeletable');
}
