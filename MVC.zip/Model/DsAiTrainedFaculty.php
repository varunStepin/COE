<?php
App::uses('Model', 'Model');
class DsAiTrainedFaculty extends AppModel {
    var $actsAs = array('SoftDeletable');

}
