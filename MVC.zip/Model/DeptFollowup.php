<?php

App::uses('Model', 'Model');

class DeptFollowup extends AppModel {
	//public $belongsTo=array("");
    
	
}
