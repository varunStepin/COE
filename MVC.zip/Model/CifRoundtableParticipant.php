<?php
App::uses('Model', 'Model');
class CifRoundtableParticipant extends AppModel {
    var $actsAs = array('SoftDeletable');
}