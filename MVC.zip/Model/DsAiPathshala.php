<?php
App::uses('Model', 'Model');
class DsAiPathshala extends AppModel {
    var $actsAs = array('SoftDeletable');
}
